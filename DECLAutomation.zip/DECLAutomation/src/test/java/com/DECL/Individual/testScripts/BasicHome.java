package com.DECL.Individual.testScripts;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Action;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.testng.annotations.Listeners;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.DECL.commonPages.ActionDriver;
import com.DECL.commonPages.ApplicationCommonFunctions;
import com.DECL.commonPages.Constants;
import com.DECL.commonPages.LogInPage;
import com.DECL.commonPages.LogOutPage;
import com.DECL.config.InitiateApplication;
import com.DECL.pages.HomeOriginalLicenseApplicationPage2;
import com.DECL.pages.HomePage;
import com.DECL.utils.ConfigurationFileReader;
import com.DECL.utils.ExcelReader;

@Listeners(com.DECL.config.Listeners.class)
public class BasicHome extends InitiateApplication{

	@FindBy(xpath = "//*[@id='combobox-button-723' and @name='County__c']")
	WebElement countyDropDwn;
	
WebDriver driver;
	
	@Test
	@Parameters({"inputDataIndex"})
	public void basicFlow(int inputDataIndex) throws Exception {

		driver = getDriver();
		HomePage homePage = new HomePage(driver);
		ExcelReader excelReader = new ExcelReader();
		LogInPage logInPage = new LogInPage(driver);
		LogOutPage logOutPage = new LogOutPage(driver);
		ActionDriver actionDriver = new ActionDriver(driver);
		ConfigurationFileReader configFileReader = new ConfigurationFileReader();
		ApplicationCommonFunctions appCommonFunctions = new ApplicationCommonFunctions(driver);
		HomeOriginalLicenseApplicationPage2 HomeOriginalLicenseApplicationPage2 = new HomeOriginalLicenseApplicationPage2(driver);
		String inputTestDataExcelPath = Constants.INPUT_TESTDATA_PATH;
		String homelicensingSheetName = Constants.homelicensingSheetName;		
		gotoApplication(configFileReader.getApplicationUrl());
		logInPage.logInAsUser("PROGRAM USER", configFileReader.getApplicationOrg());
		homePage.clickOnLicensingTile();
		actionDriver.switchToChildWindow();
		appCommonFunctions.clickOnLink("START A NEW FORM");
		appCommonFunctions.clickOnNeutralButton("View");
		appCommonFunctions.clickOnButton("Start New full application");
		excelReader.setExcelFile(inputTestDataExcelPath, homelicensingSheetName);
		appCommonFunctions.selectRadioButton("Where do you plan to provide care?", 
				excelReader.getCellData(homelicensingSheetName, "Where do you plan to provide care?", inputDataIndex));
		appCommonFunctions.clickOnLink("Get Started");
		HomeOriginalLicenseApplicationPage2.waitForGeneralApplicationandHouseholdInformationPageLoad();
		excelReader.setExcelFile(inputTestDataExcelPath, homelicensingSheetName);
		appCommonFunctions.selectCheckboxFieldValue1("I certify that I have downloaded the authorization form.");
				//excelReader.getCellData(homelicensingSheetName, "I certify that I have downloaded the authorization form.", inputDataIndex));
		appCommonFunctions.clickOnTextField("Applicant 1 Signature");
		appCommonFunctions.enterInputTextFieldValue("Applicant 1 Signature", 
				excelReader.getCellData(homelicensingSheetName, "Applicant 1 Signature", inputDataIndex));
		
		/*
		 * Thread.sleep(2000); WebElement ClickOnfield =
		 * driver.findElement(By.xpath("//*[@id='input-721']")); ClickOnfield.click();
		 * ClickOnfield.sendKeys(Keys.TAB);
		 */
		
		appCommonFunctions.SignatureOperation();
		appCommonFunctions.clickOnButton("Save");		
		appCommonFunctions.selectRadioButton("Select your reason for submitting the application:", 
				excelReader.getCellData(homelicensingSheetName, "Select your reason for submitting the application:", inputDataIndex));
		appCommonFunctions.selectRadioButton("Select the type of home license that you are applying for:", 
				excelReader.getCellData(homelicensingSheetName, "Select the type of home license that you are applying for:", inputDataIndex));
		appCommonFunctions.enterInputTextFieldValue("Facility Phone Number", 
				excelReader.getCellData(homelicensingSheetName, "Facility Phone Number", inputDataIndex));
		appCommonFunctions.enterInputTextFieldValue("Primary Email Address", 
				excelReader.getCellData(homelicensingSheetName, "Primary Email Address", inputDataIndex));
		appCommonFunctions.enterInputTextFieldValue("First Name", 
				excelReader.getCellData(homelicensingSheetName, "First Name", inputDataIndex));
		appCommonFunctions.enterInputTextFieldValue("Last Name", 
				excelReader.getCellData(homelicensingSheetName, "Last Name", inputDataIndex));
		appCommonFunctions.enterInputTextFieldValue("Social Security Number or ITIN (Individual Taxpayer Identification Number)", 
				excelReader.getCellData(homelicensingSheetName, "Social Security Number or ITIN (Individual Taxpayer Identification Number)", inputDataIndex));
		/*
		 * appCommonFunctions.enterInputTextFieldValue("Date of Birth",
		 * excelReader.getCellData(homelicensingSheetName, "Date of Birth",
		 * inputDataIndex));
		 */
		
		WebElement dobTextBox = driver.findElement(By.xpath("//*[@id='input-61' and @type='text']"));
		dobTextBox.clear();
		dobTextBox.sendKeys(excelReader.getCellData(homelicensingSheetName, "Date of Birth",inputDataIndex));
		dobTextBox.sendKeys(Keys.TAB);
		appCommonFunctions.selectComboboxFieldDropDownValue("Gender", 
				excelReader.getCellData(homelicensingSheetName, "Gender", inputDataIndex));
		
		appCommonFunctions.enterInputTextFieldValue("FEIN", 
				excelReader.getCellData(homelicensingSheetName, "FEIN", inputDataIndex));
		appCommonFunctions.selectRadioButton("Have you been convicted or entered into a deferred sentence for ANY felony offense, ANY child abuse, or unlawful sexual behavior (in ANY state) before?", 
				excelReader.getCellData(homelicensingSheetName, "Have you been convicted or entered into a deferred sentence for ANY felony offense, ANY child abuse, or unlawful sexual behavior (in ANY state) before?", inputDataIndex));
		appCommonFunctions.selectRadioButton("Will your spouse/significant other  or another adult in the home be responsible for care of children served?", 
				excelReader.getCellData(homelicensingSheetName, "Will your spouse/significant other  or another adult in the home be responsible for care of children served?", inputDataIndex));
		Thread.sleep(5000);
		appCommonFunctions.clickOnButton("Next");
		HomeOriginalLicenseApplicationPage2.waitForGeneralApplicationandHouseholdInformationPageLoad2();
		appCommonFunctions.selectRadioButton("Have you previously held a license to provide childcare in Colorado?", 
				excelReader.getCellData(homelicensingSheetName, "Have you previously held a license to provide childcare in Colorado?", inputDataIndex));
		appCommonFunctions.clickOnButton("Next");
		//HomeOriginalLicenseApplicationPage2.waitForGeneralApplicationandHouseholdInformationPageLoad3();	
		/*
		 * appCommonFunctions.clickOnButton("New");
		 * appCommonFunctions.enterInputTextFieldValue("First Name",
		 * excelReader.getCellData(homelicensingSheetName, "First Name",
		 * inputDataIndex)); appCommonFunctions.enterInputTextFieldValue("Last Name",
		 * excelReader.getCellData(homelicensingSheetName, "Last Name",
		 * inputDataIndex)); appCommonFunctions.
		 * selectRadioButton("Does this person have a Social Security Number?",
		 * excelReader.getCellData(homelicensingSheetName,
		 * "Does this person have a Social Security Number?", inputDataIndex));
		 * WebElement dobTextBox2 =
		 * driver.findElement(By.xpath("//*[@id='input-61' and @type='text']"));
		 * dobTextBox2.clear(); dobTextBox2.sendKeys("10/09/2000");
		 * dobTextBox2.sendKeys(Keys.TAB);
		 * appCommonFunctions.selectComboboxFieldDropDownValue("Gender",
		 * excelReader.getCellData(homelicensingSheetName, "Gender", inputDataIndex));
		 * appCommonFunctions.
		 * selectComboboxFieldDropDownValue("Relationship to Applicant",
		 * excelReader.getCellData(homelicensingSheetName, "Relationship to Applicant",
		 * inputDataIndex)); appCommonFunctions.clickOnButton("Save");
		 */
		//appCommonFunctions.clickOnButton("Next");
		HomeOriginalLicenseApplicationPage2.waitForGeneralApplicationandHouseholdInformationPageLoad4();
		appCommonFunctions.enterInputTextFieldValue("Street Address", 
				excelReader.getCellData(homelicensingSheetName, "Street Address", inputDataIndex));
		appCommonFunctions.enterInputTextFieldValue("City", 
				excelReader.getCellData(homelicensingSheetName, "City", inputDataIndex));
		appCommonFunctions.enterInputTextFieldValue("Zip Code", 
				excelReader.getCellData(homelicensingSheetName, "Zip Code", inputDataIndex));
		appCommonFunctions.selectComboboxFieldDropDownValueGeneric(countyDropDwn, 
				excelReader.getCellData(homelicensingSheetName, "County", inputDataIndex));
		appCommonFunctions.selectRadioButton("Is your mailing address the same as your physical location address?", 
				excelReader.getCellData(homelicensingSheetName, "Is your mailing address the same as your physical location address?", inputDataIndex));
		appCommonFunctions.selectRadioButton("Operates Monday to Friday?", 
				excelReader.getCellData(homelicensingSheetName, "Operates Monday to Friday?", inputDataIndex));
		appCommonFunctions.enterInputTextFieldValue("Monday-Friday Start Time", 
				excelReader.getCellData(homelicensingSheetName, "Monday-Friday Start Time", inputDataIndex));
		//Thread.sleep(5000);
		appCommonFunctions.enterInputTextFieldValue("Monday-Friday End Time", 
				excelReader.getCellData(homelicensingSheetName, "Monday-Friday End Time", inputDataIndex));
		//Thread.sleep(5000);
		appCommonFunctions.selectRadioButton("Operates Year round Only?", 
				excelReader.getCellData(homelicensingSheetName, "Operates Year round Only?", inputDataIndex));
		/*
		 * appCommonFunctions.selectRadioButton("Open Summer Only?",
		 * excelReader.getCellData(homelicensingSheetName, "Open Summer Only?",
		 * inputDataIndex));
		 * appCommonFunctions.selectRadioButton("Open School Year Only?",
		 * excelReader.getCellData(homelicensingSheetName, "Open School Year Only?",
		 * inputDataIndex));
		 */
		appCommonFunctions.clickOnButton("Next");
		HomeOriginalLicenseApplicationPage2.waitForGeneralApplicationandHouseholdInformationPageLoad5();
		//appCommonFunctions.selectCheckboxFieldValue1("checkbox-697");
		appCommonFunctions.clickOnButton("Next");
		HomeOriginalLicenseApplicationPage2.waitForGeneralApplicationandHouseholdInformationPageLoad6();
		appCommonFunctions.selectCheckboxFieldValue1("I have read and am fully familiar with the licensing rules regulating family care homes and/or the general rules and regulations for child care facilities issued by the Colorado Department of Human Services (CDHS) and I agree to fully comply with them.");
		appCommonFunctions.selectCheckboxFieldValue1("I understand that until a license is issued, it is illegal for me to care for children other than specified in Statute or specifically listed under the exemptions in the general rules and regulations.");
		appCommonFunctions.selectCheckboxFieldValue1("I understand that before a child care license is issued, a licensing inspection must be completed. I agree to cooperate with the Department in its inspection to determine conformity with the regulations. I understand that if issued a child care license, it will designate the number and ages of children for which care may be given. Further, I understand that if I fail to maintain the rules and regulations, the license is subject to revocation.");
        appCommonFunctions.selectCheckboxFieldValue1("I authorize the Colorado Department of Human Services (CDHS) to run the child abuse and neglect check for all people listed as living in the family child care home, regardless of age, including myself.");
        appCommonFunctions.selectCheckboxFieldValue1("I authorize the Colorado Department of Human Services (CDHS) to obtain child abuse and neglect reports for all people listed on this application, regardless of age, upon initial licensure and every five years thereafter.");
        appCommonFunctions.selectCheckboxFieldValue1("I understand that the applicant(s) AND any person 18 years of age or older who resides in the family care home are required to submit a complete set of fingerprints to the Colorado Bureau of Investigation (CBI) for a criminal check of CBI and FBI records.");
        appCommonFunctions.selectCheckboxFieldValue1("I understand that those who require fingerprinting are responsible for paying for all fingerprinting costs.");
        appCommonFunctions.selectCheckboxFieldValue1("I understand that all adults who submit fingerprints for this license must sign the Privacy Act Notification prior to, or at the time of, being fingerprinted. I also understand the Privacy Act Notification must be maintained at the licensed child care home and made available to the Department upon request.");
        appCommonFunctions.selectCheckboxFieldValue1("I understand and authorize the Department to check the status of any fingerprints for people listed as living in the family child care home through the approved fingerprint vendor.");
        appCommonFunctions.selectCheckboxFieldValue1("I agree to adhere to the non-discrimination provisions of Title VI of the Civil Rights Act of 1964, the Age Discrimination Act of 1975, the Rehabilitation Act of 1973, and Titles I through V of the Americans with Disabilities Act, as amended, and their implementation regulations which prohibit discrimination on the grounds of race, color, national origin, age, or disability.");
        appCommonFunctions.selectCheckboxFieldValue1("I understand that upon receipt by the Colorado Department of Human Services, this application becomes a public record.");
        appCommonFunctions.selectCheckboxFieldValue1("The responses I provide on this application are correct to the best of my ability. I understand that providing false information to the Colorado Department of Human Services could result in my being fined as much as $100 a day to a maximum of $10,000.");
        appCommonFunctions.clickOnTextField("Signature of Applicant 1 (Primary Applicant)");
		appCommonFunctions.enterInputTextFieldValue("Signature of Applicant 1 (Primary Applicant)", 
				excelReader.getCellData(homelicensingSheetName, "Signature of Applicant 1 (Primary Applicant)", inputDataIndex));		
		appCommonFunctions.SignatureOperation();
		appCommonFunctions.clickOnButton("Save");
		/*
		 * appCommonFunctions.
		 * clickOnTextField("Signature of Applicant 1 (Primary Applicant)");
		 * appCommonFunctions.
		 * enterInputTextFieldValue("Signature of Applicant 1 (Primary Applicant)",
		 * excelReader.getCellData(homelicensingSheetName,
		 * "Signature of Applicant 1 (Primary Applicant)", inputDataIndex));
		 * appCommonFunctions.clickOnCanvas("Canvas");
		 * appCommonFunctions.clickOnButton("Save");
		 */
		appCommonFunctions.clickOnButton("Next");
		HomeOriginalLicenseApplicationPage2.waitForGeneralApplicationandHouseholdInformationPageLoad7();
		appCommonFunctions.clickOnButton("Next");
		appCommonFunctions.clickOnButton("Print PDF");
		appCommonFunctions.clickOnButton("Next");
        logOutPage.logOut();
	}
}